module.exports = {
	function populateGameQuestions() {
	    const gameQuestions = [];
	    const indexList = [];
	    let index = questions.length;

	    if (GAME_LENGTH > index) {
	        throw new Error('Invalid Game Length.');
	    }

	    for (let i = 0; i < questions.length; i += 1) {
	        indexList.push(i);
	    }

	    // Pick GAME_LENGTH random questions from the list to ask the user, make sure there are no repeats.
	    for (let j = 0; j < GAME_LENGTH; j += 1) {
	        const rand = Math.floor(Math.random() * index);
	        index -= 1;

	        const temp = indexList[index];
	        indexList[index] = indexList[rand];
	        indexList[rand] = temp;
	        gameQuestions.push(indexList[index]);
	    }

	    return gameQuestions;
	}
	/**
 * Get the answers for a given question, and place the correct answer at the spot marked by the
 * correctAnswerTargetLocation variable. Note that you can have as many answers as you want but
 * only ANSWER_COUNT will be selected.
 * */
function populateRoundAnswers(gameQuestionIndexes, correctAnswerIndex, correctAnswerTargetLocation) {
    const answers = [];
    const answersCopy = questions[gameQuestionIndexes[correctAnswerIndex]][Object.keys(questions[gameQuestionIndexes[correctAnswerIndex]])[0]].slice();

    let index = answersCopy.length;
    let temp;

    if (index < ANSWER_COUNT) {
        throw new Error('Not enough answers for question.');
    }

    // Shuffle the answers, excluding the first element which is the correct answer.
    for (let j = 1; j < answersCopy.length; j += 1) {
        const rand = Math.floor(Math.random() * (index - 1)) + 1;
        index -= 1;

        temp = answersCopy[index];
        answersCopy[index] = answersCopy[rand];
        answersCopy[rand] = temp;
    }

    // Swap the correct answer into the target location
    for (let i = 0; i < ANSWER_COUNT; i += 1) {
        answers[i] = answersCopy[i];
    }
    temp = answers[0];
    answers[0] = answers[correctAnswerTargetLocation];
    answers[correctAnswerTargetLocation] = temp;
    return answers;
}

function isAnswerSlotValid(intent) {
    const answerSlotFilled = intent && intent.slots && intent.slots.Answer && intent.slots.Answer.value;
    const answerSlotIsInt = answerSlotFilled && !isNaN(parseInt(intent.slots.Answer.value, 10));
    return answerSlotIsInt && parseInt(intent.slots.Answer.value, 10) < (ANSWER_COUNT + 1) && parseInt(intent.slots.Answer.value, 10) > 0;
}

function handleUserGuess(userGaveUp) {
    const answerSlotValid = isAnswerSlotValid(this.event.request.intent);
    let speechOutput = '';
    let speechOutputAnalysis = '';
    const gameQuestions = this.attributes.questions;
    let correctAnswerIndex = parseInt(this.attributes.correctAnswerIndex, 10);
    let currentScore = parseInt(this.attributes.score, 10);
    let currentQuestionIndex = parseInt(this.attributes.currentQuestionIndex, 10);
    const correctAnswerText = this.attributes.correctAnswerText;

    if (answerSlotValid && parseInt(this.event.request.intent.slots.Answer.value, 10) === this.attributes.correctAnswerIndex) {
        currentScore += 1;
        speechOutputAnalysis = 'correct. ';
    } else {
        if (!userGaveUp) {
            speechOutputAnalysis = 'wrong. ';
        }

        speechOutputAnalysis += `The correct answer is ${correctAnswerIndex}: ${correctAnswerText}. `;
    }

    // Check if we can exit the game session after GAME_LENGTH questions (zero-indexed)
    if (this.attributes.currentQuestionIndex === GAME_LENGTH - 1) {
        speechOutput = userGaveUp ? '' : 'That answer is ';
        speechOutput += `${speechOutputAnalysis}You got ${currentScore.toString()} out of ${
            GAME_LENGTH.toString()} questions correct. Thank you for playing!`;

        this.emit(':tell', speechOutput);
    } else {
        currentQuestionIndex += 1;
        correctAnswerIndex = Math.floor(Math.random() * (ANSWER_COUNT));
        const spokenQuestion = Object.keys(questions[gameQuestions[currentQuestionIndex]])[0];
        const roundAnswers = populateRoundAnswers(gameQuestions, currentQuestionIndex, correctAnswerIndex);
        const questionIndexForSpeech = currentQuestionIndex + 1;
        let repromptText = `Question ${questionIndexForSpeech.toString()}. ${spokenQuestion} `;

        for (let i = 0; i < ANSWER_COUNT; i += 1) {
            repromptText += `${(i + 1).toString()}. ${roundAnswers[i]}. `;
        }

        speechOutput += userGaveUp ? '' : 'That answer is ';
        speechOutput += `${speechOutputAnalysis}Your score is ${currentScore.toString()}. ${repromptText}`;

        Object.assign(this.attributes, {
            speechOutput: repromptText,
            repromptText,
            currentQuestionIndex,
            correctAnswerIndex: correctAnswerIndex + 1,
            questions: gameQuestions,
            score: currentScore,
            correctAnswerText:
                questions[gameQuestions[currentQuestionIndex]][Object.keys(questions[gameQuestions[currentQuestionIndex]])[0]][0],
        });

        this.emit(':askWithCard', speechOutput, repromptText, GAME_NAME, repromptText);
    }
}
}